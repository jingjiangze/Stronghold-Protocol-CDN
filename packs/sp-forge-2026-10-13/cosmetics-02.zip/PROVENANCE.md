# 来源说明（PROVENANCE）· cosmetics-02 v1.0.0

## 1 原作者
时装美术（立绘 / 头像 / Spine 模型）版权归鹰角网络 / Yostar；线上构建未署名个人（原件未署名）。切片与打包：jingjiangze。

## 2 许可
代码 GPL-3.0-or-later；时装美术 © Hypergryph / Yostar（含官方素材），仅非商业学习与个人娱乐

## 3 兼容改写者
jingjiangze。

## 4 来源
线上构建 https://weishuxieyi.icu/_build/f638115c25cd-20/assets/cosmetics/<皮肤目录>/ 共 53 套（逐文件原样复制，未裁剪、未转码、未重绘）。

## 5 改了什么
- 只做了两件事：① 把目录搬进包内 assets/skins/<皮肤目录>/；② 按 pack.json 的 skins 闭集字段（id / charId / name / series / art）声明出来。
- 皮肤 id 一律沿用已上线 skin-catalogue 的写法（长名 ambienceSynesthesia → ambSyn），不另起 id 空间。
- charId 取自线上 data/assets.json 的 chars 归属；name / series 优先取 skin-catalogue，缺失时退回线上皮肤条目自带的 name。
- Spine 的 anims / animations / events / pma 照抄线上条目，不改一个动画名。
- 已被别的上线包带过的时装不重复收录（makoto-yuki 的 char_4217_makoto_p3r_1、ave-mujica 的自建 skin/op/ 目录）。

## 6 自带素材来源（逐条清点）
- 54,086,235 B / 424 个文件（含官方素材）

---
非商业声明：本包与其内含的《明日方舟》相关数据、美术、音频素材版权归鹰角网络 / Yostar 所有，
本包与其无任何关联，不主张任何权利，仅供非商业的学习与个人娱乐使用，请勿用于任何商业场景。
提取与打包：jingjiangze，2026-10-13。目标引擎口径：Stronghold-Protocol-Forge 0.18.3（上游 0.2.5）/ MOD API 1。
线上来源：https://weishuxieyi.icu/_build/f638115c25cd-20/（build f638115c25cd-20 / app 0.2.1）
