# 来源说明（PROVENANCE）· i18n-online-gaps v1.0.0

## 1 原作者
原文与译文由线上构建持有方提供，未署名个人（原件未署名）。

## 2 许可
GPL-3.0-or-later（切片）；文案本身 © Hypergryph / Yostar。

## 3 兼容改写者
jingjiangze。

## 4 来源
线上构建 https://weishuxieyi.icu/_build/f638115c25cd-20/i18n/{en,ja,ko,zh-TW}.json ↔ 引擎 0.18.3 public/i18n/ 同文件，逐键差集。

## 5 改了什么
- 只取「引擎缺失」的键；引擎已有的键一个不写（写了也生效不了：i18n 合并永不覆盖）。
- 剔掉 `_meta`（值是对象，不是字符串 ⇒ I18N_BAD_VALUE）。
- 同键不同值的 293 条韩文 / 9 条日文措辞差异没有打包，通道不允许覆盖，已在 description 里写明。

## 6 自带素材来源（逐条清点）
- 无素材，只有 4 份 JSON 文案表。

---
非商业声明：本包与其内含的《明日方舟》相关数据、美术、音频素材版权归鹰角网络 / Yostar 所有，
本包与其无任何关联，不主张任何权利，仅供非商业的学习与个人娱乐使用，请勿用于任何商业场景。
提取与打包：jingjiangze，2026-10-13。目标引擎口径：Stronghold-Protocol-Forge 0.18.3（上游 0.2.5）/ MOD API 1。
线上来源：https://weishuxieyi.icu/_build/f638115c25cd-20/（build f638115c25cd-20 / app 0.2.1）
